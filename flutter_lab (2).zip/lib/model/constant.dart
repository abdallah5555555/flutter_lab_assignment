import 'dessert_model.dart';

List<DessertModel> getInitialDesserts() {
  return [
    DessertModel(name: 'Frozen yogurt', calories: 159),
    DessertModel(name: 'Ice cream sandwich', calories: 237),
    DessertModel(name: 'Eclair', calories: 262),
    DessertModel(name: 'Cupcake', calories: 305),
    DessertModel(name: 'Gingerbread', calories: 356),
    DessertModel(name: 'Jelly bean', calories: 375),
    DessertModel(name: 'Lollipop', calories: 392),
    DessertModel(name: 'Honeycomb', calories: 408),
    DessertModel(name: 'Donut', calories: 452),
  ];
}

class DessertModel {
  final String name;
  final int calories;
  bool isSelected;

  DessertModel({
    required this.name,
    required this.calories,
    this.isSelected = false,
  });
}

import 'package:flutter/material.dart';
import 'screens/dice_screen.dart';
import 'screens/nutrition_screen.dart';

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Flutter Lab',
      //
      // home: DiceScreen(),
      //home: NutritionScreen(),
      home: DiceScreen(),
    );
  }
}

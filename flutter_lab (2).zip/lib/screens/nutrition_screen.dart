import 'package:flutter/material.dart';
import '../model/constant.dart';
import '../model/dessert_model.dart';

class NutritionScreen extends StatefulWidget {
  const NutritionScreen({super.key});

  @override
  State<NutritionScreen> createState() => _NutritionScreenState();
}

class _NutritionScreenState extends State<NutritionScreen> {
  late List<DessertModel> _desserts;

  @override
  void initState() {
    super.initState();
    _desserts = getInitialDesserts();
  }

  int get totalCalories {
    return _desserts
        .where((item) => item.isSelected)
        .fold(0, (sum, item) => sum + item.calories);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () {},
        ),
        title: const Text('Data tables'),
        backgroundColor: Colors.blue,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Nutrition',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 10),
            Card(
              elevation: 2,
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: DataTable(
                  columnSpacing: 20,
                  showCheckboxColumn: true,
                  columns: const [
                    DataColumn(label: Text('Dessert (100g serving)')),
                    DataColumn(label: Text('Calories'), numeric: true),
                  ],
                  rows: _desserts.map((dessert) {
                    return DataRow(
                      selected: dessert.isSelected,
                      onSelectChanged: (selected) {
                        setState(() {
                          dessert.isSelected = selected ?? false;
                        });
                      },
                      cells: [
                        DataCell(Text(dessert.name)),
                        DataCell(Text(dessert.calories.toString())),
                      ],
                    );
                  }).toList(),
                ),
              ),
            ),
            const SizedBox(height: 20),
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.blue.shade200),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Total Calories:',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    '$totalCalories kcal',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.blue.shade800,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
